Synth folder for serial adder with 8 parallel adder instanced.
