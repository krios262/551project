Synth folder for serial adder with 4 parallel adder instance.
