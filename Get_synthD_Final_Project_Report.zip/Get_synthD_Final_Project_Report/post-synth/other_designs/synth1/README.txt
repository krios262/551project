
Synth folder for all serial operations. 
