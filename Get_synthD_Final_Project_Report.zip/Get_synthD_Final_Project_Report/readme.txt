This is the submission folder for team Get synth'D
Authors: Evan T, David G, Rakesh R, Ajay S

The top level of the post-synth and pre-synth folder contains the 
chosen optimal design and all necessary files to compile/simulate that design.
A sub-folder named other_designs, contains all other design optimization
files.  In order to run CVP14 with the other designs, the proper parameters
must be set in CVP14 and the cooresponding files in the other_designs folder
must be linked.

The top level of post-synth has the optimal design, CVP14_synth9.vg,
along with its testbench, area and timing reports.